package com.exponent.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exponent.DAO.StudentDao;
import com.exponent.Entity.Student;

@Service
public class StudentServiceIMPL implements StudentService {

	@Autowired
	private StudentDao sd;

	@Override
	public void addStudentInServiceImpl(Student student) {

		System.out.println("I am in Service Layer");

		sd.addStudentinDaoIMPL(student);

	}

}
