package com.exponent.Service;

import com.exponent.Entity.Student;

public interface StudentService {

	public void addStudentInServiceImpl(Student student);
}
