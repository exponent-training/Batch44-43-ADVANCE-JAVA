package com.exponent.DAO;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.exponent.Entity.Student;

@Repository
public class StudentDaoIMPL implements StudentDao {

	@Autowired
	private SessionFactory sf;

	@Override
	public void addStudentinDaoIMPL(Student student) {

		System.out.println("I am in Dao Layer");
		Session s = sf.openSession();
		s.save(student);
		s.beginTransaction().commit();
		System.out.println("Success!!");

	}

}
