package com.exponent.DAO;

import com.exponent.Entity.Student;

public interface StudentDao {

	public void addStudentinDaoIMPL(Student student);

}
