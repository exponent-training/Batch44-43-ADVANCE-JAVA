package com.exponent.Controller;

import java.nio.channels.SeekableByteChannel;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.exponent.Entity.Student;
import com.exponent.Service.StudentService;

@Controller
public class HomeController {

	@Autowired
	private StudentService ss;

	private static final String adminUsername = "admin";

	private static final String adminPassword = "admin123";

//	Student st = new Student();

	@RequestMapping(value = "/log")
	public String getData(@RequestParam("uname") String un, @RequestParam("password") String ps, Model model) {

		if (un.equals(adminUsername) && ps.equals(adminPassword)) {
			model.addAttribute("msg", "Hi Browser (Client) THis value is from SERVER (Controller)");
			return "success";
		} else {
			return "error";
		}

	}

	@RequestMapping(value = "/reg")
	public String RegisterData(@ModelAttribute Student student, Model model) {

		System.out.println("--------------------Data----------------");
		System.out.println(student);

		System.out.println("I am in Controller");
		ss.addStudentInServiceImpl(student);

		model.addAttribute("stu", student);

		return "success";

	}

}
