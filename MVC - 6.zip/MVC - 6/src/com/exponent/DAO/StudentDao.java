package com.exponent.DAO;

import java.util.List;

import com.exponent.Entity.Student;

public interface StudentDao {

	public void addStudentinDaoIMPL(Student student);

	public List<Student> getStudentFromDao();

}
