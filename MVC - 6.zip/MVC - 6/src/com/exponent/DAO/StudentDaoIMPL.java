package com.exponent.DAO;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.exponent.Entity.Student;

@Repository
public class StudentDaoIMPL implements StudentDao {

	@Autowired
	private SessionFactory sf;

	@Override
	public void addStudentinDaoIMPL(Student student) {

		System.out.println("I am in Dao Layer");
		Session s = sf.openSession();
		s.save(student);
		s.beginTransaction().commit();
		System.out.println("Success!!");

	}

	@Override
	public List<Student> getStudentFromDao() {

		Session s = sf.openSession();
		Query query = s.createQuery("from Student");
		List<Student> listOfStudent = query.getResultList();

		return listOfStudent;
	}

}
