package com.exponent.Service;

import java.util.List;

import com.exponent.Entity.Student;

public interface StudentService {

	public void addStudentInServiceImpl(Student student);

	public List<Student> getStudentFromService();
}
