package com.exponent.configuration;

import java.util.Properties;

import org.hibernate.cfg.Environment;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@Configuration
@ComponentScan(basePackages = "com.exponent")
@EnableWebMvc
public class AppConfig {

	@Bean
	public InternalResourceViewResolver view() {
		InternalResourceViewResolver irv = new InternalResourceViewResolver();

		irv.setSuffix(".jsp");

		return irv;
	}

	@Bean
	public DriverManagerDataSource dataSource() {
		DriverManagerDataSource d = new DriverManagerDataSource();
		d.setDriverClassName("com.mysql.jdbc.Driver");
		d.setUrl("jdbc:mysql://localhost:3306/practice");
		d.setUsername("root");
		d.setPassword("root");
		return d;
	}

	@Bean
	public LocalSessionFactoryBean hibernateprops() {
		LocalSessionFactoryBean ls = new LocalSessionFactoryBean();
		ls.setDataSource(dataSource());

		Properties props = new Properties();
		props.setProperty(Environment.DIALECT, "org.hibernate.dialect.MySQLDialect");
		props.setProperty(Environment.HBM2DDL_AUTO, "update");
		props.setProperty(Environment.SHOW_SQL, "true");

		ls.setHibernateProperties(props);

//		ls.setAnnotatedClasses(Student.class);

		return ls;

	}

}
