package com.exponent.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController {

	@RequestMapping(value = "/log")
	public String getMsg(@RequestParam("uname") String un, @RequestParam("password") String ps) {

		System.out.println("Username is  :- " + un);
		System.out.println("Password is  :- " + ps);

		return "success";
	}

}
