package com.exponent.DAO;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.exponent.Entity.Student;

public interface StudentDao {

	public void addStudentinDaoIMPL(Student student);

	public List<Student> getStudentFromDao();

	public List<Student> sendStudentIdToDao(int studentid);

	public Student editStudentDEtailsinDao(int studentid);

	public List<Student> updateStudeninDao(Student student);

	public void sendFiletoDao(MultipartFile file);

}
