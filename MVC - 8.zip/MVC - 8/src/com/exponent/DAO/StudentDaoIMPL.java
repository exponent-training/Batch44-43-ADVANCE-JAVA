package com.exponent.DAO;

import java.util.Date;
import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.multipart.MultipartFile;

import com.exponent.Entity.FileData;
import com.exponent.Entity.Student;

@Repository
public class StudentDaoIMPL implements StudentDao {

	@Autowired
	private SessionFactory sf;

	@Override
	public void addStudentinDaoIMPL(Student student) {

		System.out.println("I am in Dao Layer");
		Session s = sf.openSession();
		s.save(student);
		s.beginTransaction().commit();
		System.out.println("Success!!");

	}

	@Override
	public List<Student> getStudentFromDao() {

		Session s = sf.openSession();
		Query query = s.createQuery("from Student");
		List<Student> listOfStudent = query.getResultList();

		return listOfStudent;
	}

	@Override
	public List<Student> sendStudentIdToDao(int studentid) {

		Session s = sf.openSession();
		Student student = s.get(Student.class, studentid);
		s.delete(student);
		s.beginTransaction().commit();
		System.out.println("data deleted sucessfullly");

		Query query = s.createQuery("from Student");
		List<Student> listOfStudent = query.getResultList();

		return listOfStudent;

	}

	@Override
	public Student editStudentDEtailsinDao(int studentid) {

		Session s = sf.openSession();
		Student student = s.get(Student.class, studentid);

		return student;
	}

	@Override
	public List<Student> updateStudeninDao(Student student) {

		Session s = sf.openSession();
		s.update(student);
		s.beginTransaction().commit();

		System.out.println("Updated!!");

		Query query = s.createQuery("from Student");
		List<Student> listOfStudent = query.getResultList();

		return listOfStudent;
	}

	@Override
	public void sendFiletoDao(MultipartFile file) {

		try {
			FileData fd = new FileData();
			fd.setFname(file.getOriginalFilename());
			fd.setDate(new Date());
			fd.setFiledata(file.getBytes());

			Session s = sf.openSession();
			s.save(fd);
			s.beginTransaction().commit();
		} catch (Exception e) {
			// TODO: handle exception
		}

	}

}
