package com.exponent.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;

import com.exponent.Entity.Student;
import com.exponent.Service.StudentService;

@Controller
public class HomeController {

	@Autowired
	private StudentService ss;

//	Student st = new Student();

	@RequestMapping(value = "/log")
	public String getData(@RequestParam("uname") String un, @RequestParam("password") String ps, Model model) {

		List<Student> listStudent = ss.getStudentFromService();

		boolean flag = false;
		for (Student student : listStudent) {
			if (student.getStudentUserName().equals(un) && student.getStudentPassword().equals(ps)) {

				flag = true;
				break;
			}
		}

		if (flag) {

			model.addAttribute("msg", listStudent);
			return "success";
		} else {
			model.addAttribute("msg", "invalid credential");
			return "login";
		}
// task -> Fetch and show single student Details
	}

	@RequestMapping(value = "/reg")
	public String RegisterData(@ModelAttribute Student student, Model model) {

		System.out.println("--------------------Data----------------");
		System.out.println(student);

		System.out.println("I am in Controller");
		ss.addStudentInServiceImpl(student);

		model.addAttribute("stu", student);

		return "login";

	}

	@RequestMapping(value = "/del")
	public String deleteStudent(@RequestParam("sid") int studentid, Model model) {

		List<Student> listStudent = ss.sendStudentIDtoService(studentid);

		model.addAttribute("msg", listStudent);

		return "success";
	}

	@RequestMapping(value = "/edit")
	public String editStudentDetails(@RequestParam("sid") int studentid, Model model) {

		Student student = ss.editStudentDetailsinService(studentid);

		model.addAttribute("msg", student);

		return "edit";
	}

	@RequestMapping(value = "/update")
	public String editStudentDetails(@ModelAttribute Student student, Model model) {

		List<Student> listStudent = ss.updateStudentinService(student);

		model.addAttribute("msg", listStudent);

		return "success";
	}

	@RequestMapping(value = "/upload")
	public String fileUploadMethod(@RequestPart MultipartFile file) {

		ss.sendFileToService(file);

		return "login";
	}

}
