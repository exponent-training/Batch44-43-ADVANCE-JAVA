package com.exponent.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.exponent.DAO.StudentDao;
import com.exponent.Entity.Student;

@Service
public class StudentServiceIMPL implements StudentService {

	@Autowired
	private StudentDao sd;

	@Override
	public void addStudentInServiceImpl(Student student) {

		System.out.println("I am in Service Layer");

		sd.addStudentinDaoIMPL(student);

	}

	@Override
	public List<Student> getStudentFromService() {

		List<Student> listStudent = sd.getStudentFromDao();

		return listStudent;
	}

	@Override
	public List<Student> sendStudentIDtoService(int studentid) {

		return sd.sendStudentIdToDao(studentid);

	}

	@Override
	public Student editStudentDetailsinService(int studentid) {

		return sd.editStudentDEtailsinDao(studentid);
	}

	@Override
	public List<Student> updateStudentinService(Student student) {
		
		return sd.updateStudeninDao(student);
	}

}
