package com.exponent.Service;

import java.util.List;

import com.exponent.Entity.Student;

public interface StudentService {

	public void addStudentInServiceImpl(Student student);

	public List<Student> getStudentFromService();

	public List<Student> sendStudentIDtoService(int studentid);

	public Student editStudentDetailsinService(int studentid);

	public List<Student> updateStudentinService(Student student);
}
