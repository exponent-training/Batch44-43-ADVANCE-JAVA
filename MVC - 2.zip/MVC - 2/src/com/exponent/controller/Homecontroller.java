package com.exponent.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class Homecontroller {

	@RequestMapping(value = "/log")
	public void getMsg() {
		System.out.println("Hello Iam GetMSG ");
		System.out.println("Your frontend request is here !!! ");
		System.out.println("And there name is log");
	}
}
