package com.exponent.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController {

	@RequestMapping(value = "/log")
	public String getMsg(@RequestParam("uname") String un, @RequestParam("password") String ps, Model model) {

		System.out.println("Username is  :- " + un);
		System.out.println("Password is  :- " + ps);

		model.addAttribute("msg", un + " " + ps);

		return "success";
	}

}
